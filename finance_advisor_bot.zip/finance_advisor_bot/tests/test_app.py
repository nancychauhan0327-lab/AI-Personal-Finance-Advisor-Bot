from app import create_app
from config import Config

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SECRET_KEY = "test"

def test_home():
    app = create_app(TestConfig)
    with app.test_client() as c:
        assert c.get("/").status_code == 200

def test_register_login():
    app = create_app(TestConfig)
    with app.test_client() as c:
        r = c.post("/register", data={"name":"Test","email":"test@example.com","password":"password123"}, follow_redirects=True)
        assert r.status_code == 200
        assert b"Welcome" in r.data
