# AI Personal Finance Advisor Bot

A full-stack Flask personal finance application with authentication, income/expense tracking, category budgets, savings goals, dashboard analytics, and optional OpenAI/Gemini recommendations.

## 1. Setup

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows
# cp .env.example .env   # macOS/Linux
python run.py
```

Open `http://127.0.0.1:5000`.

## 2. AI configuration

Edit `.env`:

```env
AI_PROVIDER=openai
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-5-mini
```

or:

```env
AI_PROVIDER=gemini
GEMINI_API_KEY=your_key
GEMINI_MODEL=gemini-2.5-flash
```

Leave `AI_PROVIDER=none` for a fully local demo without AI.

## 3. PostgreSQL

Set `DATABASE_URL` to your PostgreSQL connection string, then run the app. The SQLAlchemy models are compatible with SQLite and PostgreSQL.

## 4. Ngrok

After starting Flask:

```bash
ngrok http 5000
```

Use the generated HTTPS forwarding URL for external demonstrations. Do not expose real financial data or production secrets in a public demo.

## 5. Tests

```bash
pytest -q
```

## Project structure

- `app/models.py` — database models
- `app/routes/auth.py` — registration/login/logout
- `app/routes/finance.py` — income, expenses, budgets, savings
- `app/routes/main.py` — dashboard
- `app/routes/ai.py` — AI advisor
- `app/services/ai.py` — OpenAI/Gemini abstraction
- `app/templates/` — Jinja2 UI
- `app/static/` — CSS/JS assets
- `tests/` — automated tests
- `.env.example` — environment configuration template
