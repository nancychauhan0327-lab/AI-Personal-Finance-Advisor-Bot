import json
from flask import current_app

def build_prompt(summary):
    return f"""You are a cautious personal-finance assistant. Analyze this user's monthly summary and return practical, non-judgmental suggestions. Do not claim to be a licensed financial advisor. Avoid recommending specific securities or regulated financial products. Clearly separate calculations from suggestions.\n\nData:\n{json.dumps(summary, indent=2)}\n\nReturn 5 concise recommendations covering budgeting, spending, savings, emergency fund planning, and one potential cost optimization."""

def generate_advice(summary):
    provider = current_app.config["AI_PROVIDER"]
    prompt = build_prompt(summary)
    if provider == "openai" and current_app.config["OPENAI_API_KEY"]:
        from openai import OpenAI
        client = OpenAI(api_key=current_app.config["OPENAI_API_KEY"])
        r = client.responses.create(model=current_app.config["OPENAI_MODEL"], input=prompt)
        return r.output_text
    if provider == "gemini" and current_app.config["GEMINI_API_KEY"]:
        from google import genai
        client = genai.Client(api_key=current_app.config["GEMINI_API_KEY"])
        r = client.models.generate_content(model=current_app.config["GEMINI_MODEL"], contents=prompt)
        return r.text
    return "AI is not configured yet. Add AI_PROVIDER and the matching API key in .env to enable personalized recommendations."
