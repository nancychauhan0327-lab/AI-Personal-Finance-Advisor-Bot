from datetime import date
from flask import Blueprint, render_template, request
from flask_login import login_required, current_user
from ..services.ai import generate_advice

ai_bp = Blueprint("ai", __name__, url_prefix="/ai")

@ai_bp.route("/advisor", methods=["GET", "POST"])
@login_required
def advisor():
    month = request.form.get("month") or date.today().strftime("%Y-%m")
    incomes = [x for x in current_user.incomes if x.date.strftime("%Y-%m") == month]
    expenses = [x for x in current_user.expenses if x.date.strftime("%Y-%m") == month]
    summary = {"month": month, "income": round(sum(x.amount for x in incomes),2),
               "expenses": round(sum(x.amount for x in expenses),2),
               "by_category": {}}
    for x in expenses: summary["by_category"][x.category.name] = round(summary["by_category"].get(x.category.name,0)+x.amount,2)
    advice = generate_advice(summary) if request.method == "POST" else None
    return render_template("advisor.html", month=month, summary=summary, advice=advice)
