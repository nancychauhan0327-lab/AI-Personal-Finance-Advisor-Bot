from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import func
from ..extensions import db
from ..models import User, ExpenseCategory

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated: return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 8:
            flash("Enter a name, valid email, and password of at least 8 characters.", "danger")
        elif db.session.scalar(db.select(User).where(func.lower(User.email) == email)):
            flash("An account with that email already exists.", "danger")
        else:
            user = User(name=name, email=email); user.set_password(password)
            db.session.add(user); db.session.flush()
            for name in ["Housing", "Food", "Transport", "Utilities", "Entertainment", "Health", "Education", "Shopping", "Other"]:
                if not db.session.scalar(db.select(ExpenseCategory).where(ExpenseCategory.name == name)):
                    db.session.add(ExpenseCategory(name=name))
            db.session.commit(); login_user(user)
            return redirect(url_for("main.dashboard"))
    return render_template("register.html")

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated: return redirect(url_for("main.dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower(); password = request.form.get("password", "")
        user = db.session.scalar(db.select(User).where(func.lower(User.email) == email))
        if user and user.check_password(password): login_user(user); return redirect(request.args.get("next") or url_for("main.dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@auth_bp.route("/logout")
@login_required
def logout(): logout_user(); return redirect(url_for("auth.login"))
