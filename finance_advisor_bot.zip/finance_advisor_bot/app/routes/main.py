from collections import defaultdict
from datetime import date
from flask import Blueprint, render_template
from flask_login import login_required, current_user
from ..models import Income, Expense, Budget, Savings
from ..extensions import db

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
def index(): return render_template("index.html")

@main_bp.route("/dashboard")
@login_required
def dashboard():
    month = date.today().strftime("%Y-%m")
    income = sum(x.amount for x in current_user.incomes if x.date.strftime("%Y-%m") == month)
    expenses = [x for x in current_user.expenses if x.date.strftime("%Y-%m") == month]
    expense_total = sum(x.amount for x in expenses)
    category_totals = defaultdict(float)
    for x in expenses: category_totals[x.category.name] += x.amount
    budget_total = sum(x.limit_amount for x in current_user.budgets if x.month == month)
    saving = income - expense_total
    return render_template("dashboard.html", month=month, income=income, expense_total=expense_total,
                           saving=saving, budget_total=budget_total, category_totals=dict(category_totals),
                           recent_expenses=sorted(expenses, key=lambda x:x.date, reverse=True)[:8])
