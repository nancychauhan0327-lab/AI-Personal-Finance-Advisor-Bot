from datetime import date
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from ..extensions import db
from ..models import Income, Expense, ExpenseCategory, Budget, Savings

finance_bp = Blueprint("finance", __name__, url_prefix="/finance")

def parse_amount(value):
    try:
        n = float(value); return n if n >= 0 else None
    except (TypeError, ValueError): return None

@finance_bp.route("/income", methods=["GET", "POST"])
@login_required
def income():
    if request.method == "POST":
        amount = parse_amount(request.form.get("amount"))
        if amount is None or not request.form.get("source"): flash("Enter a valid source and amount.", "danger")
        else:
            db.session.add(Income(user_id=current_user.id, source=request.form["source"], amount=amount,
                                  date=date.fromisoformat(request.form.get("date") or str(date.today())), note=request.form.get("note")))
            db.session.commit(); flash("Income added.", "success")
        return redirect(url_for("finance.income"))
    items = sorted(current_user.incomes, key=lambda x:x.date, reverse=True)
    return render_template("income.html", items=items)

@finance_bp.route("/expenses", methods=["GET", "POST"])
@login_required
def expenses():
    categories = db.session.scalars(db.select(ExpenseCategory).order_by(ExpenseCategory.name)).all()
    if request.method == "POST":
        amount = parse_amount(request.form.get("amount")); category_id = request.form.get("category_id")
        if amount is None or not category_id: flash("Enter a valid amount and category.", "danger")
        else:
            db.session.add(Expense(user_id=current_user.id, category_id=int(category_id), amount=amount,
                                   date=date.fromisoformat(request.form.get("date") or str(date.today())), note=request.form.get("note")))
            db.session.commit(); flash("Expense added.", "success")
        return redirect(url_for("finance.expenses"))
    items = sorted(current_user.expenses, key=lambda x:x.date, reverse=True)
    return render_template("expenses.html", items=items, categories=categories)

@finance_bp.route("/budget", methods=["GET", "POST"])
@login_required
def budget():
    categories = db.session.scalars(db.select(ExpenseCategory).order_by(ExpenseCategory.name)).all()
    if request.method == "POST":
        amount = parse_amount(request.form.get("limit_amount"))
        if amount is None or not request.form.get("category_id") or not request.form.get("month"): flash("Enter all budget fields.", "danger")
        else:
            db.session.add(Budget(user_id=current_user.id, category_id=int(request.form["category_id"]), limit_amount=amount, month=request.form["month"]))
            db.session.commit(); flash("Budget saved.", "success")
        return redirect(url_for("finance.budget"))
    items = sorted(current_user.budgets, key=lambda x:x.month, reverse=True)
    return render_template("budget.html", items=items, categories=categories)

@finance_bp.route("/savings", methods=["GET", "POST"])
@login_required
def savings():
    if request.method == "POST":
        target = parse_amount(request.form.get("target_amount")); saved = parse_amount(request.form.get("saved_amount"))
        if target is None or saved is None or not request.form.get("month"): flash("Enter valid savings details.", "danger")
        else:
            db.session.add(Savings(user_id=current_user.id, month=request.form["month"], target_amount=target, saved_amount=saved)); db.session.commit(); flash("Savings goal saved.", "success")
        return redirect(url_for("finance.savings"))
    return render_template("savings.html", items=sorted(current_user.savings, key=lambda x:x.month, reverse=True))
